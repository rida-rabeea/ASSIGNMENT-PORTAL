from flask import Flask, request, render_template, redirect, session, flash, send_from_directory
import os
import sqlite3
import difflib
import shutil


app = Flask(__name__)
app.secret_key = 'your_secure_secret_key'  # Use a secure secret key for session management




app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['ALLOWED_EXTENSIONS'] = {'txt', 'docx', 'pdf'}

# Utility function to connect to the database
def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row  # Enable dictionary-like access to rows
    return conn



@app.route('/')
def home():
    return render_template('home.html')  # Home page with student/teacher buttons

# Student and teacher login routes
@app.route('/student_login')
def student_login_page():
    return render_template('login.html', role='student')

@app.route('/teacher_login')
def teacher_login_page():
    return render_template('login.html', role='teacher')

@app.route('/student_login', methods=['POST'])
def student_login():
    email = request.form.get('email')
    password = request.form.get('password')

    if not email or not password:
        flash("Both email and password fields are required.", "error")
        return render_template('login.html', role='student')

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students WHERE email = ? AND password = ?", (email, password))
    student = cursor.fetchone()
    conn.close()

    if student:
        session['user_id'] = student['id']
        session['user_name'] = student['name']
        session['user_usn'] = student['usn']
        session['user_email'] = student['email']
        session['role'] = 'student'
        return redirect('/student_dashboard')
    else:
        flash("Invalid email or password.", "error")
        return render_template('login.html', role='student')

@app.route('/teacher_login', methods=['POST'])
def teacher_login():
    email = request.form.get('email')
    password = request.form.get('password')

    if not email or not password:
        flash("Both email and password fields are required.", "error")
        return render_template('login.html', role='teacher')

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM teachers WHERE email = ? AND password = ?", (email, password))
    teacher = cursor.fetchone()
    conn.close()

    if teacher:
        session['user_id'] = teacher['teacher_id']
        session['user_name'] = teacher['name']
        session['user_email'] = teacher['email']
        session['role'] = 'teacher'
        return redirect('/teacher_dashboard')
    else:
        flash("Invalid email or password.", "error")
        return render_template('login.html', role='teacher')

# Dashboard routes
@app.route('/student_dashboard')
def student_dashboard():
    if 'role' in session and session['role'] == 'student':
        student_name = session['user_name']
        student_usn = session.get('user_usn', '')
        student_email = session['user_email']

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, title, description, deadline FROM assignments")
        rows = cursor.fetchall()
        conn.close()

        assignments = [{"id": row['id'], "title": row['title'], "description": row['description'], "deadline": row['deadline']} for row in rows]
        return render_template('student_dashboard.html', name=student_name, usn=student_usn, email=student_email, assignments=assignments)
    return redirect('/')

@app.route('/teacher_dashboard')
def teacher_dashboard():
    if 'role' in session and session['role'] == 'teacher':
        teacher_name = session['user_name']
        teacher_email = session['user_email']

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, title, description, deadline FROM assignments")
        rows = cursor.fetchall()
        conn.close()

        assignments = [{"id": row['id'], "title": row['title'], "description": row['description'], "deadline": row['deadline']} for row in rows]
        return render_template('teacher_dashboard.html', name=teacher_name, email=teacher_email, assignments=assignments)
    return redirect('/')

@app.route('/create_assignment', methods=['GET', 'POST'])
def create_assignment():
    if 'role' in session and session['role'] == 'teacher':
        if request.method == 'POST':
            assignment_id = request.form['assignment_id']
            title = request.form['title']
            description = request.form['description']
            deadline = request.form['deadline']

            if not assignment_id or not title or not description or not deadline:
                flash("All fields are required.", "error")
                return redirect('/create_assignment')

            try:
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute(
                    "INSERT INTO assignments (id, title, description, deadline) VALUES (?, ?, ?, ?)",
                    (assignment_id, title, description, deadline)
                )
                conn.commit()
                conn.close()
                flash(f"Assignment '{title}' created successfully!", "success")
                return redirect('/teacher_dashboard')
            except sqlite3.IntegrityError as e:
                flash("Assignment ID already exists. Please use a unique ID.", "error")
                return redirect('/create_assignment')
        return render_template('create_assignment.html')
    else:
        flash("Access denied.", "error")
        return redirect('/')

# View submissions route
@app.route('/view_submissions', methods=['GET'])
def view_submissions():
    if 'role' in session and session['role'] == 'teacher':
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT name, usn, assignment_id, submission_content FROM submissions")
        submissions = cursor.fetchall()
        conn.close()

        submission_list = [
            {
                "name": row["name"],
                "usn": row["usn"],
                "assignment_id": row["assignment_id"],
                "submission_content": row["submission_content"]  # This is the file name
            }
            for row in submissions
        ]

        return render_template('view_submissions.html', submissions=submission_list)
    else:
        flash("Access denied.", "error")
        return redirect('/')


@app.route('/download_file/<path:filename>')
def download_file(filename):
    try:
        # Define the path to the reports and uploads directories
        reports_folder = os.path.join(os.getcwd(), 'reports')
        uploads_folder = os.path.join(os.getcwd(), 'uploads')

        # Check if the file exists in the reports folder
        file_path_in_reports = os.path.join(reports_folder, filename)
        if os.path.exists(file_path_in_reports):
            # Ensure the uploads folder exists, create it if it doesn't
            os.makedirs(uploads_folder, exist_ok=True)

            # Define the destination path in the uploads folder
            file_path_in_uploads = os.path.join(uploads_folder, filename)

            # Copy the file from reports to uploads folder
            shutil.copy(file_path_in_reports, file_path_in_uploads)

            # Return the file from the uploads folder as an attachment
            return send_from_directory(uploads_folder, filename, as_attachment=True)
        else:
            flash("File not found in reports folder.", "error")
            return redirect('/view_submissions')
    except Exception as e:
        flash(f"An error occurred: {str(e)}", "error")
        return redirect('/view_submissions')
    

@app.route('/check_plagiarism_dashboard', methods=['GET', 'POST'])
def check_plagiarism_dashboard():
    plagiarism_result = None  # Default to None in case no result is found

    if request.method == 'POST':
        try:
            # Get the uploaded file
            uploaded_file = request.files['file']
            
            # Define the path to the uploads folder
            uploads_folder = os.path.join(os.getcwd(), 'uploads')

            # Ensure the uploads folder exists
            if not os.path.exists(uploads_folder):
                os.makedirs(uploads_folder)

            # Save the uploaded file to the uploads folder
            uploaded_file_path = os.path.join(uploads_folder, uploaded_file.filename)
            uploaded_file.save(uploaded_file_path)

            # Read the contents of the uploaded file
            with open(uploaded_file_path, 'r', encoding='ISO-8859-1') as file:
                uploaded_text = file.read()

            # Compare with reference texts (these could be predefined or dynamically fetched)
            reference_texts = get_reference_texts()  # Replace with your method to fetch reference content
            plagiarism_percentage = check_plagiarism_with_difflib(uploaded_text, reference_texts)

            # Prepare the plagiarism result message
            plagiarism_result = f"Plagiarism Percentage: {plagiarism_percentage}%"
            if plagiarism_percentage > 50:
                plagiarism_result += " - Warning! High plagiarism detected."

        except Exception as e:
            flash(f"An error occurred: {str(e)}", "error")
    
    # Render the page, passing the plagiarism result (if available)
    return render_template('check_plagiarism_dashboard.html', plagiarism_result=plagiarism_result)

def get_reference_texts():
    # This is a placeholder function to retrieve reference texts.
    # In a real-world scenario, you might fetch this from a database or files.
    # For demonstration, we'll use a few example texts.
    
    return [
        "This is some sample text that will be used for comparison.",
        "Another piece of text to check for plagiarism.",
        "This content is original and should not match others.",
        "Plagiarism detection is important for ensuring the quality of work."
    ]


def check_plagiarism_with_difflib(uploaded_text, reference_texts):
    # Use difflib to compare the uploaded file with reference texts
    plagiarism_scores = []

    for reference_text in reference_texts:
        # Compare the uploaded text with the reference text using SequenceMatcher
        sequence_matcher = difflib.SequenceMatcher(None, uploaded_text, reference_text)
        similarity_ratio = sequence_matcher.ratio()
        plagiarism_scores.append(similarity_ratio)

    # Calculate average plagiarism score (percentage)
    # We use the highest similarity score to determine the plagiarism percentage
    avg_plagiarism_score = max(plagiarism_scores) * 100  # Convert to percentage
    return round(avg_plagiarism_score, 2)


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
