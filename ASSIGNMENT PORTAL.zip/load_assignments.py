import sqlite3
import csv

# Student database
def load_csv_to_db_assignments(csv_file):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()



    # Recreate the table
    cursor.execute(''' 
        CREATE TABLE IF NOT EXISTS assignments (
            id INTEGER PRIMARY KEY, 
            title TEXT NOT NULL,
            description TEXT NOT NULL UNIQUE,
            deadline TEXT UNIQUE NOT NULL
        )
    ''')

    # Read the new CSV file and insert data into the table
    with open(csv_file, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            cursor.execute('''
                INSERT OR IGNORE INTO assignments (id,title, description, deadline)
                VALUES (?,?,?,?)
            ''', (row['id'],row['title'], row['description'], row['deadline']))

    conn.commit()
    conn.close()

# Call the function with your CSV file name for students
load_csv_to_db_assignments('assign.csv')


