from flask import Flask, request, render_template, redirect, session, jsonify
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Use a secure secret key for session management

@app.route('/')
def home():
    return render_template('home.html')  # Home page with student/teacher buttons

# Route for student login page
@app.route('/student_login')
def student_login_page():
    return render_template('login.html', role='student')

# Route for teacher login page
@app.route('/teacher_login')
def teacher_login_page():
    return render_template('login.html', role='teacher')

# Route for student login form submission
@app.route('/student_login', methods=['POST'])
def student_login():
    email = request.form.get('email')
    password = request.form.get('password')

    if not email or not password:
        return render_template('login.html', error="Both fields are required.", role='student')

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students WHERE email = ? AND password = ?", (email, password))
    student = cursor.fetchone()
    conn.close()

    if student:
        session['student_id'] = student[0]
        session['student_name'] = student[1]
        return redirect('/dashboard_student')
    else:
        return render_template('login.html', error="Invalid email or password", role='student')

# Route for teacher login form submission
@app.route('/teacher_login', methods=['GET', 'POST'])
def teacher_login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        if not email or not password:
            return render_template('login.html', error="Both fields are required.", role='teacher')

        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM teachers WHERE email = ? AND password = ?", (email, password))
        teacher = cursor.fetchone()
        conn.close()

        if teacher:
            session['teacher_id'] = teacher[0]
            session['teacher_name'] = teacher[1]
            session['email'] = teacher[2]  # Store teacher email for dashboard
            return redirect('/dashboard_teacher')
        else:
            return render_template('login.html', error="Invalid email or password", role='teacher')

    



