from flask import Flask, request, render_template, redirect, session, flash
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secure_secret_key'  # Use a secure secret key for session management

# Utility function to connect to the database
def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row  # Enable dictionary-like access to rows
    return conn

@app.route('/')
def home():
    return render_template('home.html')  # Home page with student/teacher buttons

# Route for student login page
@app.route('/student_login')
def student_login_page():
    return render_template('login.html', role='student')

# Route for teacher login page
@app.route('/teacher_login')
def teacher_login_page():
    return render_template('login.html', role='teacher')

# Shared login function
def login_user(email, password, role):
    conn = get_db_connection()
    cursor = conn.cursor()
    table = "students" if role == "student" else "teachers"
    cursor.execute(f"SELECT * FROM {table} WHERE email = ? AND password = ?", (email, password))
    user = cursor.fetchone()
    conn.close()
    return user

# Route for student login form submission
@app.route('/student_login', methods=['POST'])
def student_login():
    email = request.form.get('email')
    password = request.form.get('password')

    if not email or not password:
        flash("Both email and password fields are required.", "error")
        return render_template('login.html', role='student')

    student = login_user(email, password, "student")
    if student:
        # Store student details in session
        session['user_id'] = student['id']
        session['user_name'] = student['name']
        session['user_usn'] = student['usn']
        session['user_email'] = student['email']
        session['role'] = 'student'
        return redirect('/student_dashboard')
    else:
        flash("Invalid email or password.", "error")
        return render_template('login.html', role='student')

# Route for teacher login form submission
@app.route('/teacher_login', methods=['POST'])
def teacher_login():
    email = request.form.get('email')
    password = request.form.get('password')

    if not email or not password:
        flash("Both email and password fields are required.", "error")
        return render_template('login.html', role='teacher')

    teacher = login_user(email, password, "teacher")
    if teacher:
        # Store teacher details in session
        session['user_id'] = teacher['teacher_id']
        session['user_name'] = teacher['name']
        session['user_email'] = teacher['email']
        session['role'] = 'teacher'
        return redirect('/teacher_dashboard')
    else:
        flash("Invalid email or password.", "error")
        return render_template('login.html', role='teacher')

# Route for student dashboard
@app.route('/student_dashboard')
def student_dashboard():
    if 'role' in session and session['role'] == 'student':
        # Fetch student details from session
        student_name = session['user_name']
        student_usn = session.get('user_usn', '')
        student_email = session['user_email']

        # Connect to the database and fetch assignments
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, title, description, deadline FROM assignments")
        rows = cursor.fetchall()
        conn.close()

        # Prepare the list of assignments
        assignments = [{"id": row['id'], "title": row['title'], "description": row['description'], "deadline": row['deadline']} for row in rows]

        return render_template('student_dashboard.html', 
                               name=student_name, 
                               usn=student_usn, 
                               email=student_email,
                               assignments=assignments)
    return redirect('/')  # Redirect to home if not logged in

# Route for teacher dashboard
@app.route('/teacher_dashboard')
def teacher_dashboard():
    if 'role' in session and session['role'] == 'teacher':
        # Fetch teacher details from session
        teacher_name = session['user_name']
        teacher_email = session['user_email']

        # Connect to the database and fetch assignments created by the teacher
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, title, description, deadline FROM assignments")
        rows = cursor.fetchall()
        conn.close()

        # Prepare the list of assignments
        assignments = [{"id": row['id'], "title": row['title'], "description": row['description'], "deadline": row['deadline']} for row in rows]

        return render_template('teacher_dashboard.html', 
                               name=teacher_name, 
                               email=teacher_email,
                               assignments=assignments)
    return redirect('/')  # Redirect to home if not logged in

# Route for logout
@app.route('/logout')
def logout():
    session.clear()  # Clear the session
    return redirect('/')  # Redirect to home page

if __name__ == '__main__':
    app.run(debug=True)
