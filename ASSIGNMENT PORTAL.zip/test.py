import sqlite3

conn=sqlite3.connect('database.db')
cursor=conn.cursor()

cursor.execute('SELECT * from submissions')

sample=cursor.fetchall()

for i in sample:
    print(i[0], i[1], i[2],i[3])


conn.close()