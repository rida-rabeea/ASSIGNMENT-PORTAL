import sqlite3
import csv

# Submissions database
def load_csv_to_db_submissions(csv_file):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("DROP TABLE IF EXISTS submissions")
    
    # Create the submissions table
    cursor.execute(''' 
        CREATE TABLE IF NOT EXISTS submissions (
            name TEXT NOT NULL,
            usn TEXT NOT NULL UNIQUE,
            assignment_id INTEGER NOT NULL,
            submission_content BLOB NOT NULL,
            FOREIGN KEY (assignment_id) REFERENCES assignments (id)
        )
    ''')

    # Read the new CSV file and insert data into the table
    with open(csv_file, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            cursor.execute('''
                INSERT OR IGNORE INTO submissions (name, usn, assignment_id, submission_content)
                VALUES (?, ?, ?, ?)
            ''', (
                row['name'], 
                row['usn'], 
                row['assignment_id'], 
                row['submission_content'], 
            
            ))

    conn.commit()
    conn.close()

# Call the function with your CSV file name for submissions

load_csv_to_db_submissions('submissions.csv')
